const express = require('express');
const app = express();
const bodyparser = require('body-parser');
//const ls = require('node-localstorage');


// USES
app.use(bodyparser.urlencoded({extended : true}));
app.use(express.static(__dirname + '/views/site/'));

// SETS
app.set('view engine','ejs');
app.set('views','./views');



// GETS,POSTS
app.get('/', function(req, res){
    res.render('site/index');
});

app.get('/pagina-de-busca', function(req, res) {
    // erro abaixo
    //var captura = window.document.getElementById('textoDeBusca').value;;
    var teste = "1"
  //  var pesquisa = captura
    res.render('site/pagina-de-busca', {var1 :teste});
    
});

var server = app.listen(5000, function(){
    console.log('Node esta rodando ..');
});
