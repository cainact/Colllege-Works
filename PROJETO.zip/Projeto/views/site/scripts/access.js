var captura ="";

caption = function(){
    captura = document.getElementById('textoDeBusca').value;
    sessionStorage.setItem('pesquisa', captura);
}



/*
const { Client} = require('pg')
const connectionString ='postgressql://postgres:123@localhost:5432/postgres'

const client = new Client({
    connectionString:connectionString
})

client.connect()

client.query('SELECT * from politicos',(err,res)=>{
    console.log(err,res)
    client.end()
})
*/
